vasicek_pdf = function(x, alpha, beta, sigma, delta_T, r0 = 0.05){
  e <- r0*exp(-alpha*delta_T)+beta*(1-exp(-alpha*delta_T))
  s <- sigma^2/(2*alpha)*(1-exp(-2*alpha*delta_T))
  dnorm(x, mean = e, sd = s)
}

x <- seq(-0.1, 0.2, length = 1000)
par(xpd = T ,mar = c(2,2,2,2), mfrow = c(2,2))
y <- sapply(c(10, 5, 3, 2), function(delta_T)
       vasicek_pdf(x, .2, 0.1, 0.15, delta_T))

par(xpd = T ,mar = c(2,2,2,2), mfrow = c(2,2))  
matplot(x, y, type = "l",ylab ="",xlab = "")
legend("topleft", c("T-t = 2", "T-t = 3", "T-t = 5", "T-t = 10"), lty = 1:4, col=1:4, cex = 0.7)

y <- sapply(c(0.1, 0.12, 0.14, 0.16), function(beta)
       vasicek_pdf(x, .2, beta, 0.15, 5))
matplot(x, y, type = "l", ylab ="",xlab = "")
legend("topleft", c("beta = 0.1", "beta = 0.12", "beta = 0.14", "beta = 0.16"), lty = 1:4, col=1:4,cex = 0.7)

y <- sapply(c(.1, .2, .3, .4), function(alpha)
       vasicek_pdf(x, alpha, 0.1, 0.15, 5))

matplot(x, y, type = "l", ylab ="",xlab = "")
legend("topleft", c("alpha = 0.1", "alpha = 0.2", "alpha = 0.3", "alpha = 0.4"), lty = 1:4, col=1:4, cex = 0.7)

y <- sapply(c(.1, .12, .14, .15), function(sigma)
       vasicek_pdf(x, .1, 0.1, sigma, 5))

matplot(x, y, type = "l", ylab ="",xlab = "")
legend("topleft", c("sigma = 0.1", "sigma = 0.12", "sigma = 0.14", "sigma = 0.15"), lty = 1:4, col=1:4, cex = 0.7)

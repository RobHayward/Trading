CIR_pdf = function(x, alpha, beta, sigma, delta_T, r0 = 0.1){
  q = (2*alpha*beta)/(sigma^2) - 1
  c = (2*alpha)/(sigma^2*(1-exp(-alpha*delta_T)))
  u = c*r0*exp(-alpha*delta_T)
  2*c*dchisq(2*c*x, 2*q+2, ncp = 2*u)
}

x <- seq(0, 0.15, length = 1000)
y <- sapply(c(1, 2, 5, 50), function(delta_T)
       CIR_pdf(x, .3, 0.05,0.1,delta_T))

par(mar = c(2,2,2,2), mfrow = c(2,2))  
matplot(x, y, type = "l",ylab ="",xlab = "")
legend("topright", c("T-t = 1", "T-t = 2", "T-t = 5", "T-t = 50"), lty = 1:4, col = 1:4, cex = 0.7)

y <- sapply(c(.2, .4, .6, 1), function(alpha)
       CIR_pdf(x, alpha, 0.05,0.1,1))
  matplot(x, y, type = "l",ylab ="",xlab = "")
legend("topright", c("alpha = 0.2", "alpha = 0.4", "alpha = 0.6", "alpha = 1"), lty = 1:4, col = 1:4, cex = 0.7)

y <- sapply(c(.1, .12, .14, .16), function(beta)
       CIR_pdf(x, .3, beta,0.1,1))
  
matplot(x, y, type = "l",ylab ="",xlab = "")
legend("topleft", c("beta = 0.1", "beta = 0.12", "beta = 0.14", "beta = 0.16"), lty = 1:4, col = 1:4, cex = 0.7)

x <- seq(0, 0.25, length = 1000)
y <- sapply(c(.03, .05, .1, .15), function(sigma)
       CIR_pdf(x, .3, 0.05,sigma,1))
  
matplot(x, y, type = "l",ylab ="",xlab = "")
legend("topright", c("sigma = 1", "sigma = 5", "sigma = 10", "sigma = 15"), lty = 1:4, col = 1:4, cex = 0.7)
